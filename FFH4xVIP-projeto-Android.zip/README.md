# FFH4x VIP — projeto Android inicial

Projeto Android Studio em Kotlin, compatível com Android 6.0 (API 23) ou superior.

## O que funciona nesta versão
- Interface FFH4x VIP em tema escuro/vermelho.
- Controles de valores de referência para Geral, Ponto vermelho, 2x, 4x e AWM.
- Salvar e carregar um perfil localmente no aparelho.
- Botões para abrir Free Fire e Free Fire MAX se estiverem instalados.

## Limites importantes
Este é um painel auxiliar: ele **não modifica o Free Fire**, não injeta código, não altera arquivos do jogo, não cria mira automática e não contorna proteções. Os valores são referências para ajuste manual nas configurações do jogo. Não há login em servidor nesta primeira versão; os perfis ficam armazenados localmente.

## Gerar APK
1. Abra a pasta `FFH4xVIP` no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Se necessário, instale Android SDK Platform 35.
4. Escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Pacotes reconhecidos:
- Free Fire: `com.dts.freefireth`
- Free Fire MAX: `com.dts.freefiremax`

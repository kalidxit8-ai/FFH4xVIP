plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ffh4x.vip"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ffh4x.vip"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

package com.ffh4x.vip

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.text.InputType

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ffh4x_profiles", MODE_PRIVATE) }
    private val red = Color.rgb(255, 55, 75)
    private val bg = Color.rgb(14, 14, 19)
    private lateinit var status: TextView
    private lateinit var profileName: EditText
    private lateinit var general: SeekBar
    private lateinit var redDot: SeekBar
    private lateinit var twoX: SeekBar
    private lateinit var fourX: SeekBar
    private lateinit var sniper: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("FFH4x VIP", 30, red, true))
        content.addView(label("PAINEL DE PERFIS • ANDROID", 12, Color.LTGRAY, false))
        status = label("Pronto para configurar seu perfil.", 14, Color.WHITE, false)
        status.setPadding(0, 18, 0, 16)
        content.addView(status)

        content.addView(section("SELECIONE O JOGO"))
        content.addView(actionButton("ABRIR FREE FIRE", "com.dts.freefireth"))
        content.addView(actionButton("ABRIR FREE FIRE MAX", "com.dts.freefiremax"))

        content.addView(section("PERFIL DE SENSIBILIDADE"))
        profileName = EditText(this).apply {
            hint = "Nome do perfil (ex.: Minha configuração)"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(true)
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(35,35,43))
        }
        content.addView(profileName, matchWrap())
        general = addSlider(content, "Geral")
        redDot = addSlider(content, "Ponto vermelho")
        twoX = addSlider(content, "Mira 2x")
        fourX = addSlider(content, "Mira 4x")
        sniper = addSlider(content, "AWM / Sniper")

        content.addView(actionButton("SALVAR PERFIL", null) { saveProfile() })
        content.addView(actionButton("CARREGAR PERFIL SALVO", null) { loadProfile() })
        content.addView(actionButton("RESTAURAR VALORES PADRÃO", null) { resetValues() })

        content.addView(section("IMPORTANTE"))
        content.addView(label(
            "Este app salva valores de referência para você ajustar manualmente nas configurações do jogo. Ele não injeta código, não altera arquivos do Free Fire e não oferece mira automática. A disponibilidade dos jogos depende de estarem instalados no aparelho.",
            13, Color.LTGRAY, false
        ).apply { setPadding(0, 4, 0, 20) })

        setContentView(root)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun section(text: String) = label(text, 15, red, true).apply {
        setPadding(0, 22, 0, 10)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 12
    }

    private fun addSlider(parent: LinearLayout, title: String): SeekBar {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f }
        val seek = SeekBar(this).apply { max = 200; progress = 100; progressTintList = android.content.res.ColorStateList.valueOf(red); thumbTintList = android.content.res.ColorStateList.valueOf(red) }
        fun update() { heading.text = "$title: ${seek.progress}" }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = update()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        update()
        wrap.addView(heading)
        wrap.addView(seek)
        wrap.setPadding(0, 4, 0, 8)
        parent.addView(wrap, matchWrap())
        return seek
    }

    private fun actionButton(text: String, packageName: String?, click: (() -> Unit)? = null): Button =
        Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(150, 25, 45))
            isAllCaps = false
            setOnClickListener {
                if (click != null) click()
                else if (packageName != null) launchGame(packageName)
            }
            layoutParams = matchWrap()
        }

    private fun launchGame(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) {
            startActivity(launch)
            status.text = "Abrindo ${if (pkg.endsWith("max")) "Free Fire MAX" else "Free Fire"}..."
        } else {
            status.text = "Jogo não encontrado. Instale essa versão pela loja oficial."
        }
    }

    private fun saveProfile() {
        val name = profileName.text.toString().trim().ifEmpty { "Meu perfil" }
        prefs.edit().putString("name", name)
            .putInt("general", general.progress).putInt("reddot", redDot.progress)
            .putInt("2x", twoX.progress).putInt("4x", fourX.progress)
            .putInt("sniper", sniper.progress).apply()
        status.text = "Perfil '$name' salvo neste aparelho."
    }

    private fun loadProfile() {
        if (!prefs.contains("general")) {
            status.text = "Nenhum perfil salvo ainda."
            return
        }
        profileName.setText(prefs.getString("name", "Meu perfil"))
        general.progress = prefs.getInt("general", 100)
        redDot.progress = prefs.getInt("reddot", 100)
        twoX.progress = prefs.getInt("2x", 100)
        fourX.progress = prefs.getInt("4x", 100)
        sniper.progress = prefs.getInt("sniper", 100)
        status.text = "Perfil carregado. Aplique os valores manualmente no jogo."
    }

    private fun resetValues() {
        listOf(general, redDot, twoX, fourX, sniper).forEach { it.progress = 100 }
        status.text = "Valores de referência restaurados."
    }
}
